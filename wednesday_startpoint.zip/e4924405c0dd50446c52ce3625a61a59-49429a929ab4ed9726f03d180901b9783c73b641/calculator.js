`use strict`
import * as DOM from './dom.js';